import numpy as np
from glob import glob

orig_nuclear = np.loadtxt("trimmed_realnuc.txt", usecols=1)
orig_mt = np.loadtxt("trimmed_realnucmito.txt", usecols=1)

nuclear_diffs = []
mito_diffs = []

# Simulted nuc - nuc
for f in glob("trimmed_bootstrap_nuclear_*.txt"):
    samp = np.loadtxt(f, usecols=1)
    nuclear_diffs.append(np.sum(samp - orig_nuclear))

# Simulated mito - mito
for f in glob("trimmed_bootstrap_mito_like_*.txt"):
    samp = np.loadtxt(f, usecols=1)
    mito_diffs.append(np.sum(samp - orig_mt))

# Summarize
print("Simulated Nuclear - Nuclear:")
print(f" Mean: {np.mean(nuclear_diffs):.4f}, SE: {np.std(nuclear_diffs, ddof=1)/np.sqrt(len(nuclear_diffs)):.4f}") 

print("Simulated Mito - Mito:")
print(f" Mean: {np.mean(mito_diffs):.4f}, SE: {np.std(mito_diffs, ddof=1)/np.sqrt(len(mito_diffs)):.4f}") 
