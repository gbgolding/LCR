import numpy as np


# Step 1: Load the data
large_sample = np.loadtxt('human_nuc_values.txt')
small_sample = np.loadtxt('human_truebacteria_lcrs.txt')

# Step 2: Combine samples 
combined = np.concatenate([small_sample, large_sample])
n_small = len(small_sample)
n_large = len(large_sample)

# Step 3: Compute observed difference in means
obs_diff = np.mean(small_sample) - np.mean(large_sample)

# Step 4: Permutation test
n_permutations = 10000
perm_diffs = [] # stores mean differences from each permutation test

for _ in range(n_permutations):
    np.random.shuffle(combined)
    group1 = combined[:n_small] 
# random group with sample size = small sample size
    group2 = combined[n_small:]
# random group with sample size = large sample size
    perm_diffs.append(np.mean(group1) - np.mean(group2))

perm_diffs = np.array(perm_diffs)

# Step 5: Calculate p-value
p_value = np.mean(np.abs(perm_diffs) >= np.abs(obs_diff))

print(f"Observed difference in means: {obs_diff:.4f}")
print(f"P-value (two-sided): {p_value:.4f}")

# Save results to a text file
#with open("permutation_test_results.txt", "w") as f:
#    f.write(f"Observed difference in means: {obs_diff:.4f}\n")
#    f.write(f"P-value (two-sided): {p_value:.4f}\n")

with open("human_truebacteria_permutation2.tsv", "w") as f:
    f.write("Type\tValue\n")
    for diff in perm_diffs:
        f.write(f"Simulated difference\t{diff:.6f}\n")
    f.write(f"Observed difference\t{obs_diff:.6f}\n")


