import sys


def parse_seg_output_with_filenames(input_path):
    """Parses a combined SEG output file with filenames and returns LCR proportions."""
    with open(input_path, "r") as f:
        lines = f.readlines()

    results = []
    current_file = None
    current_header = None
    current_sequence = ""

    for line in lines:
        line = line.strip()
        if line.startswith(">>>"):
            current_file = line.replace(">>>", "").strip()
        elif line.startswith(">"):
            if current_header and current_sequence:
                # Process the previous sequence
                x_count = current_sequence.lower().count("x")
                total_length = len(current_sequence)
                proportion_x = (x_count / total_length) if total_length > 0 else 0
                results.append((current_file, current_header, proportion_x))
            current_header = line
            current_sequence = ""
        else:
            current_sequence += line

    # Catch the last sequence
    if current_header and current_sequence:
        x_count = current_sequence.lower().count("x")
        total_length = len(current_sequence)
        proportion_x = (x_count / total_length) if total_length > 0 else 0
        results.append((current_file, current_header, proportion_x))

    return results

# Main execution
if len(sys.argv) != 2:
    print(f"Usage: python {sys.argv[0]} <combined_seg_output_file>")
    sys.exit(1)

input_file = sys.argv[1]
parsed_data = parse_seg_output_with_filenames(input_file)


output_file = f"{input_file}_with_filenames.txt"
from collections import defaultdict

# Group results by filename
grouped = defaultdict(list)
for filename, header, proportion in parsed_data:
    grouped[filename].append((header, proportion))

summary_output_file = "lcr_summary_per_file.txt"

with open(summary_output_file, "w") as summary:
    summary.write("Filename\tMax_LCR_Proportion\tAverage_LCR_Proportion\n")
    for filename in sorted(grouped):
        proportions = [prop for _, prop in grouped[filename]]
        max_prop = max(proportions)
        avg_prop = sum(proportions) / len(proportions) if proportions else 0
        summary.write(f"{filename}\t{max_prop:.4f}\t{avg_prop:.4f}\n")


# Write sorted results
with open(output_file, "w") as out:
    for filename in sorted(grouped):  # Optional: sort filenames alphabetically
        # Sort sequences by LCR proportion descending
        sorted_sequences = sorted(grouped[filename], key=lambda x: x[1], reverse=True)
        for header, proportion in sorted_sequences:
            out.write(f"{filename}\t{header}\t{proportion:.4f}\n")

print(f"Saved results to {output_file}")

